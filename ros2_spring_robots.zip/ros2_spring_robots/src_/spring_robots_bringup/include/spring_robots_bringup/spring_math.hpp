#pragma once
#include <cmath>
#include <geometry_msgs/msg/point.hpp>

namespace spring_robots {

constexpr double L1 = 0.8;  // back_arm
constexpr double L2 = 0.5;  // forearm

//x
inline geometry_msgs::msg::Point endEffectorX(
    double slide_x, double theta1_x, double theta2_x)
{
  geometry_msgs::msg::Point p;
  double angle_world = theta1_x + theta2_x; //absolute angle forearm
  p.x = slide_x +5
        + L1 * std::cos(theta1_x)
        + L2 * std::cos(angle_world);
  p.y = L1 * std::sin(theta1_x)
        + L2 * std::sin(angle_world);
  p.z = 0.0;
  return p;
}

//y
inline geometry_msgs::msg::Point endEffectorY(
    double slide_y, double theta1_y, double theta2_y)
{
  geometry_msgs::msg::Point p;
  double angle_world = theta1_y + theta2_y;
  p.x = L1 * std::sin(theta1_y)
        + L2 * std::sin(angle_world);
  p.y = slide_y +5
        + L1 * std::cos(theta1_y)
        + L2 * std::cos(angle_world);
  p.z = 0.0;
  return p;
}

//spring length
inline double springLength(
    const geometry_msgs::msg::Point & tip_x,
    const geometry_msgs::msg::Point & tip_y) {
        double dx = tip_x.x - tip_y.x;
        double dy = tip_x.y - tip_y.y;
        return std::sqrt(dx*dx + dy*dy);
    }

}