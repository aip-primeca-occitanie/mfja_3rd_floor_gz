import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import (DeclareLaunchArgument, GroupAction, TimerAction)
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node, PushRosNamespace

def generate_launch_description():

    desc_pkg  = get_package_share_directory('spring_robots_description')
    bring_pkg = get_package_share_directory('spring_robots_bringup')

    urdf_x = open(os.path.join(desc_pkg, 'staurdf', 'robot_x.urdf')).read()
    urdf_y = open(os.path.join(desc_pkg, 'urdf', 'robot_y.urdf')).read()

    controllers_x_yaml = os.path.join(bring_pkg, 'config', 'controllers_x.yaml')
    controllers_y_yaml = os.path.join(bring_pkg, 'config', 'controllers_y.yaml')
    rviz_config      = os.path.join(desc_pkg,  'rviz',   'two_robots.rviz')

    args = [
        DeclareLaunchArgument('spring_l0',   default_value='3.5',  description='m'),
        DeclareLaunchArgument('spring_k',    default_value='10.0', description='N/m'),
        DeclareLaunchArgument('kp_shoulder', default_value='3.0',  description='Gain P shoulder'),
        DeclareLaunchArgument('ki_shoulder', default_value='0.05', description='Gain I shoulder'),
        DeclareLaunchArgument('kd_shoulder', default_value='0.02', description='Gain D shoulder'),
        DeclareLaunchArgument('kp_elbow',    default_value='3.0',  description='Gain P elbow'),
        DeclareLaunchArgument('ki_elbow',    default_value='0.05', description='Gain I elbow'),
        DeclareLaunchArgument('kd_elbow',    default_value='0.02', description='Gain D elbow'),
        DeclareLaunchArgument('kp_slide',     default_value='5.0',  description='Gain P rail'),
        DeclareLaunchArgument('ki_slide',     default_value='0.1',  description='Gain I rail'),
        DeclareLaunchArgument('kd_slide',     default_value='0.05', description='Gain D rail'),
        DeclareLaunchArgument('w_spring',    default_value='10.0', description='weight error due to spring'),
        DeclareLaunchArgument('w_origin',    default_value='1.0',  description='weight error due to distance to origin'),
    ]

    shared_pid_params = {
        'spring_l0':   LaunchConfiguration('spring_l0'),
        'spring_k':    LaunchConfiguration('spring_k'),
        'kp_shoulder': LaunchConfiguration('kp_shoulder'),
        'ki_shoulder': LaunchConfiguration('ki_shoulder'),
        'kd_shoulder': LaunchConfiguration('kd_shoulder'),
        'kp_elbow':    LaunchConfiguration('kp_elbow'),
        'ki_elbow':    LaunchConfiguration('ki_elbow'),
        'kd_elbow':    LaunchConfiguration('kd_elbow'),
        'kp_slide':     LaunchConfiguration('kp_slide'),
        'ki_slide':     LaunchConfiguration('ki_slide'),
        'kd_slide':     LaunchConfiguration('kd_slide'),
        'w_spring':    LaunchConfiguration('w_spring'),
        'w_origin':    LaunchConfiguration('w_origin'),
    }

    # robot_x
    robot_x_group = GroupAction([
        PushRosNamespace('robot_x'),

        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            parameters=[{
                'robot_description': urdf_x,
                'frame_prefix': 'robot_x/',
            }],
        ),

        Node(
            package='controller_manager',
            executable='ros2_control_node',
            name='controller_manager',
            parameters=[
                {'robot_description': urdf_x},
                controllers_x_yaml,
            ],
            output='screen',
        ),

        Node(
            package='spring_robots_bringup',
            executable='spring_robot_controller',
            name='spring_robot_controller',
            parameters=[{
                'robot_id': 'robot_x',
                **shared_pid_params
            }],
            output='screen',
        ),
    ])

    robot_x_to_world = Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='robot_x_to_world',
            arguments=['0', '-5', '0', '0', '0', '0', 'world', 'robot_x/base_link_x'],
            output='screen',
        )

    # robot_y
    robot_y_group = GroupAction([
        PushRosNamespace('robot_y'),

        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            parameters=[{
                'robot_description': urdf_y,
                'frame_prefix': 'robot_y/',
            }],
        ),

        Node(
            package='controller_manager',
            executable='ros2_control_node',
            name='controller_manager',
            parameters=[
                {'robot_description': urdf_y},
                controllers_y_yaml,
            ],
            output='screen',
        ),

        Node(
            package='spring_robots_bringup',
            executable='spring_robot_controller',
            name='spring_robot_controller',
            parameters=[{
                'robot_id': 'robot_y',
                **shared_pid_params
            }],
            output='screen',
        ),
    ])

    robot_y_to_world = Node(
            package='tf2_ros',
            executable='static_transform_publisher',
            name='robot_y_to_world',
            arguments=['-5', '0', '0', '0', '0', '0', 'world', 'robot_y/base_link_y'],
            output='screen',
        )

    # controller
    def spawner(ns, controller, delay, inactive=False):
        args = [
            controller,
            '--controller-manager', f'/{ns}/controller_manager',
            '--controller-manager-timeout', '30',
        ]
        if inactive:
            args.append('--inactive')
        return TimerAction(period=float(delay), actions=[
            Node(package='controller_manager', executable='spawner', arguments=args),
        ])

    #visual
    rviz = Node(
        package='rviz2',
        executable='rviz2',
        arguments=['-d', rviz_config] if os.path.exists(rviz_config) else [],
    )

    #launch
    return LaunchDescription(
        args + [
            robot_x_group,
            robot_y_group,
            robot_x_to_world,
            robot_y_to_world,
            rviz,
            spawner('robot_x', 'joint_state_broadcaster', delay=2),
            spawner('robot_x', 'velocity_controller',     delay=5),
            spawner('robot_x', 'position_controller',     delay=8,  inactive=True),
            spawner('robot_y', 'joint_state_broadcaster', delay=2),
            spawner('robot_y', 'velocity_controller',     delay=5),
            spawner('robot_y', 'position_controller',     delay=8,  inactive=True),
        ]
    )