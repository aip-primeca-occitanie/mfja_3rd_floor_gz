#include <chrono>
#include <string>
#include <cmath>

#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/joint_state.hpp"
#include "std_msgs/msg/float64_multi_array.hpp"
#include "geometry_msgs/msg/point.hpp"

#include "spring_robots_bringup/pid_controller.hpp"
#include "spring_robots_bringup/spring_math.hpp"

using namespace std::chrono_literals;

namespace spring_robots {

class SpringRobotController : public rclcpp::Node {
    public:
    SpringRobotController() : rclcpp::Node("spring_robot_controller")
    {
        // paramters (value in launch / cmd (ex --ros-args -p kp_shoulder:=2.0))
        this->declare_parameter<std::string>("robot_id", "robot_x");
        robot_id_ = this->get_parameter("robot_id").as_string(); //robot x or y

        this->declare_parameter<double>("spring_l0", 1.0);
        this->declare_parameter<double>("spring_k",  10.0);
        l0_ = this->get_parameter("spring_l0").as_double();
        k_  = this->get_parameter("spring_k").as_double();

        this->declare_parameter<double>("kp_shoulder", 3.0);
        this->declare_parameter<double>("ki_shoulder", 0.1);
        this->declare_parameter<double>("kd_shoulder", 0.05);

        this->declare_parameter<double>("kp_elbow", 3.0);
        this->declare_parameter<double>("ki_elbow", 0.1);
        this->declare_parameter<double>("kd_elbow", 0.05);

        this->declare_parameter<double>("kp_slide", 5.0);
        this->declare_parameter<double>("ki_slide", 0.2);
        this->declare_parameter<double>("kd_slide", 0.1);

        this->declare_parameter<double>("w_spring", 10.0);
        this->declare_parameter<double>("w_origin",  1.0);
        this->declare_parameter<double>("spring_activation_threshold", 0.05);

        this->declare_parameter<double>("max_joint_vel",  1.5);
        this->declare_parameter<double>("max_slide_vel",   0.5);

        this->declare_parameter<int>("control_rate_hz", 200);

        //initialize PID
        auto make_pid = [this](const std::string & name, double max_out) {
        PIDGains g;
        g.kp         = this->get_parameter("kp_" + name).as_double();
        g.ki         = this->get_parameter("ki_" + name).as_double();
        g.kd         = this->get_parameter("kd_" + name).as_double();
        g.max_output = max_out;
        return PIDController(g);
        };

        double max_v = this->get_parameter("max_joint_vel").as_double();
        double max_r = this->get_parameter("max_slide_vel").as_double();

        pid_shoulder_ = make_pid("shoulder", max_v);
        pid_elbow_    = make_pid("elbow",    max_v);
        pid_slide_     = make_pid("slide",     max_r);

        // topics
        std::string other_id = (robot_id_ == "robot_x") ? "robot_y" : "robot_x";

        // sub to self
        sub_joint_states_ = this->create_subscription<sensor_msgs::msg::JointState>(
            "joint_states", 10, std::bind(&SpringRobotController::onJointStates, this, std::placeholders::_1));

        // sub to other
        sub_other_tip_ = this->create_subscription<geometry_msgs::msg::Point>(
            "/" + other_id + "/tip_position", 10, std::bind(&SpringRobotController::onOtherTip, this, std::placeholders::_1));

        // pub
        pub_tip_ = this->create_publisher<geometry_msgs::msg::Point>("tip_position", 10); //tip

        pub_cmd_ = this->create_publisher<std_msgs::msg::Float64MultiArray>( //command (velocity)
            "velocity_controller/commands", 10); //topic "/robot_x/velocity_controller/commands" standard format of forward_command_controller
        
        slide_pos_ = 5.0; 

        //timer
        int rate_hz = this->get_parameter("control_rate_hz").as_int();
        auto period = std::chrono::milliseconds(1000 / rate_hz);

        control_timer_ = this->create_wall_timer(
            period, std::bind(&SpringRobotController::controlLoop, this));

        last_time_ = this->now();

        RCLCPP_INFO(this->get_logger(),
            "SpringRobotController started : %s | l0=%.2f k=%.2f",
            robot_id_.c_str(), l0_, k_);

        if (robot_id_ == "robot_x") {
            TARGET_ANGLE = - TARGET_ANGLE;
            }
        }

    private:
    std::string robot_id_;
    double TARGET_ANGLE = M_PI / 4.0;
    double l0_, k_;

    PIDController pid_shoulder_ {PIDGains{}};
    PIDController pid_elbow_    {PIDGains{}};
    PIDController pid_slide_     {PIDGains{}};

    double slide_pos_     = 0.0;
    double shoulder_pos_ = 0.0;
    double elbow_pos_    = 0.0;
    bool   joint_states_received_ = false;

    geometry_msgs::msg::Point other_tip_{};
    bool other_tip_received_ = false;

    rclcpp::Time last_time_;
    rclcpp::TimerBase::SharedPtr control_timer_;
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr sub_joint_states_;
    rclcpp::Subscription<geometry_msgs::msg::Point>::SharedPtr    sub_other_tip_;
    rclcpp::Publisher<geometry_msgs::msg::Point>::SharedPtr       pub_tip_;
    rclcpp::Publisher<std_msgs::msg::Float64MultiArray>::SharedPtr pub_cmd_;
    
    void onJointStates(const sensor_msgs::msg::JointState::SharedPtr msg)
    {
        // joints in msg->name / msg->position / msg->velocity
        for (size_t i = 0; i < msg->name.size(); ++i) {
        const auto & name = msg->name[i];
        if (name.find("slide")     != std::string::npos) slide_pos_     = msg->position[i];
        if (name.find("shoulder") != std::string::npos) shoulder_pos_ = msg->position[i];
        if (name.find("elbow")    != std::string::npos) elbow_pos_    = msg->position[i];
        }
        joint_states_received_ = true;
        }

    void onOtherTip(const geometry_msgs::msg::Point::SharedPtr msg)
    {
        other_tip_ = *msg;
        other_tip_received_ = true;
        }

    //-----------
    // main loop
    //-----------
    void controlLoop()
    {
        if (!joint_states_received_) {
        RCLCPP_WARN_THROTTLE(this->get_logger(), *this->get_clock(), 2000,
            "waiting...");
        return;
        }

        // dt
        auto now = this->now();
        double dt = (now - last_time_).seconds();
        last_time_ = now;

        // compute tip
        geometry_msgs::msg::Point my_tip;
        if (robot_id_ == "robot_x") {
        my_tip = endEffectorX(slide_pos_, shoulder_pos_, elbow_pos_);
        } else {
        my_tip = endEffectorY(slide_pos_, shoulder_pos_, elbow_pos_);
        }

        // pub tip
        pub_tip_->publish(my_tip);

        //------------------------
        // compute errors for PID
        //------------------------

        //angle
        double e_shoulder = TARGET_ANGLE - shoulder_pos_ ;
        double e_elbow    = 0 - elbow_pos_;

        double cmd_shoulder = pid_shoulder_.compute(e_shoulder, dt);
        double cmd_elbow    = pid_elbow_.compute(e_elbow, dt);

        //slider
        double cmd_slide = 0.0;

        if (other_tip_received_) {
        double spring_len = springLength(my_tip, other_tip_);
        double e_spring = (2.0 * l0_) - spring_len;
        double e_origin = -slide_pos_;
        double w_spring = this->get_parameter("w_spring").as_double();
        double w_origin = this->get_parameter("w_origin").as_double();
        double threshold = this->get_parameter("spring_activation_threshold").as_double();
        double e_slide;
        if (std::abs(e_spring) > threshold) {
            e_slide = w_spring * e_spring;
        } else {
            e_slide = w_spring * e_spring + w_origin * e_origin;
        }
        cmd_slide = pid_slide_.compute(e_slide, dt);
        }

        // pub to ros2_control
        std_msgs::msg::Float64MultiArray cmd_msg;
        cmd_msg.data = {cmd_slide, cmd_shoulder, cmd_elbow};
        pub_cmd_->publish(cmd_msg);
        }
    };
}

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<spring_robots::SpringRobotController>());
  rclcpp::shutdown();
  return 0;
}