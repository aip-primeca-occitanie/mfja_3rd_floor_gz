#include <chrono>
#include <future>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <string>
#include <thread>
 
#include "rclcpp/rclcpp.hpp"
#include "sensor_msgs/msg/joint_state.hpp"
#include "std_msgs/msg/float64_multi_array.hpp"
#include "controller_manager_msgs/srv/switch_controller.hpp"
 
using namespace std::chrono_literals;
using SwitchController = controller_manager_msgs::srv::SwitchController;
 
namespace spring_robots {
 
class PositionCommander : public rclcpp::Node {
public:
    PositionCommander() : rclcpp::Node("position_commander")
    {
        pub_x_ = this->create_publisher<std_msgs::msg::Float64MultiArray>(
            "/robot_x/position_controller/commands", 10);
        pub_y_ = this->create_publisher<std_msgs::msg::Float64MultiArray>(
            "/robot_y/position_controller/commands", 10);
 
        sub_js_x_ = this->create_subscription<sensor_msgs::msg::JointState>(
            "/robot_x/joint_states", 10,
            [this](const sensor_msgs::msg::JointState::SharedPtr m){ js_x_ = *m; });
        sub_js_y_ = this->create_subscription<sensor_msgs::msg::JointState>(
            "/robot_y/joint_states", 10,
            [this](const sensor_msgs::msg::JointState::SharedPtr m){ js_y_ = *m; });
 
        sw_x_ = this->create_client<SwitchController>( //on peut pas controler en position ET en vitesse, donc on switch quand faut update la pos (teleportation)
            "/robot_x/controller_manager/switch_controller");
        sw_y_ = this->create_client<SwitchController>(
            "/robot_y/controller_manager/switch_controller");
    }
 
    void runCLI()
    {
        std::cout << "Waiting for controller_managers... ";
        sw_x_->wait_for_service();
        sw_y_->wait_for_service();
        std::cout << "OK\n";

        std::string line;
        printBanner();
        while (std::getline(std::cin, line)) {
            if (processLine(line)) break;
            printBanner();
        }
        rclcpp::shutdown();
    }
 
private:
    rclcpp::Publisher<std_msgs::msg::Float64MultiArray>::SharedPtr pub_x_, pub_y_;
    rclcpp::Subscription<sensor_msgs::msg::JointState>::SharedPtr sub_js_x_, sub_js_y_;
    rclcpp::Client<SwitchController>::SharedPtr sw_x_, sw_y_;
    sensor_msgs::msg::JointState js_x_{}, js_y_{};

    bool doSwitch(char robot,
                  const std::string & activate,
                  const std::string & deactivate)
    {
        auto & client = (robot == 'x') ? sw_x_ : sw_y_;
        auto req = std::make_shared<SwitchController::Request>();
        req->activate_controllers   = {activate};
        req->deactivate_controllers = {deactivate};
        req->strictness  = SwitchController::Request::BEST_EFFORT;
        req->activate_asap = true;
        req->timeout = rclcpp::Duration::from_seconds(2.0);
 
        auto future = client->async_send_request(req);
 
        auto deadline = std::chrono::steady_clock::now() + std::chrono::seconds(4);
        while (rclcpp::ok()) {
            if (future.wait_for(20ms) == std::future_status::ready) break;
            if (std::chrono::steady_clock::now() > deadline) {
                std::cout << "X timeout\n"; return false;
            }
            std::this_thread::sleep_for(20ms);
        }
        return true;
    }

    bool sendPosition(char robot, std::istringstream & iss)
    {
        double slide, shoulder, elbow;
        if (!(iss >> slide >> shoulder >> elbow)) {
            std::cout << "  Usage: " << robot << " <slide> <shoulder> <elbow>\n";
            return false;
        }
 
        std::cout << "  [1/3] switching velocity -> position ...\n";
        if (!doSwitch(robot, "position_controller", "velocity_controller")) {
            std::cout << "quitting...\n"; return false;
            }
        std::cout << " OK\n";
 
        std::this_thread::sleep_for(50ms);
 
        std::cout << "  [2/3] publishing ..."; std::cout.flush();
        auto & pub = (robot == 'x') ? pub_x_ : pub_y_;
        std_msgs::msg::Float64MultiArray cmd;
        cmd.data = {slide, shoulder, elbow};
        pub->publish(cmd);
        std::this_thread::sleep_for(20ms);
        std::cout << " OK\n";
 
        std::cout << "  [3/3] switch back position -> velocity ..."; std::cout.flush();
        if (!doSwitch(robot, "velocity_controller", "position_controller"))
            std::cout << "failed\n";
        else
            std::cout << "ok\n";
 
        std::cout << "done.\n";
        return false;
        }
 
    bool processLine(const std::string & line)
        {
        std::istringstream iss(line);
        std::string tok;
        if (!(iss >> tok) || tok.empty()) return false;
        if (tok == "quit") {
            std::cout << "quitting..."; return true;
            }
        if (tok == "robot_x" || tok == "robot_y") {
            std::string mode;
            if (!(iss >> mode) || mode != "pos") {
                std::cout << "  Usage: " << tok << " pos <slide> <shoulder> <elbow>\n";
                return false;
                }
            return sendPosition(tok == "robot_x" ? 'x' : 'y', iss);
            }
        if (tok == "x" || tok == "y") return sendPosition(tok[0], iss);
        std::cout << "unkown\n";
        return false;
        }
 
    void printBanner() {
        std::cout <<
            "<x/y> <slide> <shoulder> <elbow> "
            "\n Boundaries :  slide [-5, 5] m"
            "   shoulder [-1.57, 1.57] rad"
            "   elbow [-0.7, 0.7] rad\n\n";
        }
 
    };
} // namespace spring_robots
 
int main(int argc, char * argv[])
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<spring_robots::PositionCommander>();
    std::thread ros_thread([&node]() { rclcpp::spin(node); });
    node->runCLI();
    if (rclcpp::ok()) rclcpp::shutdown();
    ros_thread.join();
    return 0;
}