import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, GroupAction
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node, PushRosNamespace
import numpy as np

def generate_launch_description():
    # ------------------------------------------------------------------ #
    # Chemins vers les fichiers du package
    # ------------------------------------------------------------------ #
    pkg_share = get_package_share_directory('spring_robots_description')

    urdf_robot_x = os.path.join(pkg_share, 'urdf', 'robot_x.urdf')
    urdf_robot_y = os.path.join(pkg_share, 'urdf', 'robot_y.urdf')
    rviz_config  = os.path.join(pkg_share, 'rviz', 'two_robots.rviz')

    # Lire le contenu des fichiers URDF (robot_state_publisher attend la
    # description en tant que paramètre chaîne de caractères)
    with open(urdf_robot_x, 'r') as f:
        robot_x_description = f.read()

    with open(urdf_robot_y, 'r') as f:
        robot_y_description = f.read()

    # ------------------------------------------------------------------ #
    # Argument : utiliser RViz ou non (pratique pour le debug sans affichage)
    # ------------------------------------------------------------------ #
    use_rviz_arg = DeclareLaunchArgument(
        'use_rviz',
        default_value='true',
        description='Lancer RViz2 pour la visualisation (true/false)'
    )

    # ------------------------------------------------------------------ #
    # ROBOT X — namespace /robot_x, glisse selon l'axe X
    # ------------------------------------------------------------------ #
    robot_x_group = GroupAction([
        PushRosNamespace('robot_x'),  # Tous les topics du groupe sont préfixés /robot_x/

        # robot_state_publisher : lit l'URDF et publie les TF (transformées)
        # entre chaque lien du robot. C'est lui qui "anime" le robot dans RViz.
        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            parameters=[{
                'robot_description': robot_x_description,
                # tf_prefix ajoute un préfixe à tous les noms de frames TF.
                # Sans ça, robot_x et robot_y auraient des frames identiques
                # et TF2 serait incapable de les distinguer.
                'frame_prefix': 'robot_x/',
            }],
            output='screen',
        ),

        # joint_state_publisher_gui : publie l'état des joints et affiche
        # une fenêtre avec des sliders pour bouger chaque joint manuellement.
        Node(
            package='joint_state_publisher_gui',
            executable='joint_state_publisher_gui',
            name='joint_state_publisher_gui',
            output='screen',
        ),
    ])

    robot_x_to_world = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='robot_x_to_world',
        arguments=['0', '-5', '0', '0', '0', '0', 'world', 'robot_x/base_link_x'],
        output='screen',
    )

    # ------------------------------------------------------------------ #
    # ROBOT Y — namespace /robot_y, glisse selon l'axe Y
    # ------------------------------------------------------------------ #
    robot_y_group = GroupAction([
        PushRosNamespace('robot_y'),

        Node(
            package='robot_state_publisher',
            executable='robot_state_publisher',
            name='robot_state_publisher',
            parameters=[{
                'robot_description': robot_y_description,
                'frame_prefix': 'robot_y/',
            }],
            output='screen',
        ),

        Node(
            package='joint_state_publisher_gui',
            executable='joint_state_publisher_gui',
            name='joint_state_publisher_gui',
            output='screen',
        ),
    ])

    robot_y_to_world = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='robot_y_to_world',
        arguments=['-5', '0', '0', '0', '0', '0', 'world', 'robot_y/base_link_y'],
        output='screen',
    )

    # ------------------------------------------------------------------ #
    # RViz2 — visualisation commune des deux robots
    # ------------------------------------------------------------------ #
    # On utilise ConditionalShutdown pour ne lancer RViz que si demandé.
    # Pour l'instant on le lance toujours, mais l'argument est là pour plus tard.
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        # Si le fichier de config existe, on l'utilise ; sinon RViz démarre vide.
        arguments=['-d', rviz_config] if os.path.exists(rviz_config) else [],
        output='screen',
    )

    # ------------------------------------------------------------------ #
    # Assemblage final du LaunchDescription
    # ------------------------------------------------------------------ #
    return LaunchDescription([
        use_rviz_arg,
        robot_x_group,
        robot_y_group,
        robot_x_to_world,
        robot_y_to_world,
        rviz_node,
    ])